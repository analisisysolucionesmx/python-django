from django.urls import path
from .views import CategoriaView, CategoriaNew

urlpatterns=[
   path('categorias/',CategoriaView.as_view(), name='categoria_list'),
   path('categorias/new',CategoriaNew.as_view(), name='categoria_new'),
]